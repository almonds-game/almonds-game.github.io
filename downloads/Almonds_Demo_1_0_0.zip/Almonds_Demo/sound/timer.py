import time, threading

def timer(secs):
	global seconds
	seconds = secs
	for i in range(secs):
		time.sleep(1)
		seconds -= 1

timer_thread = threading.Thread(target=timer, args=[3])
timer_thread.start()
while seconds > 0:
	name = input("Enter a name: ")
	print("hey")
