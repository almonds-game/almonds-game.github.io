#!/bin/sh
cd $HOME/downloads/almonds_demo
./unix_resize.sh false
python3.10 almonds_demo.py 1
