import json
import os
import subprocess
import sys
import time

try:
    import bcrypt
    # import keyboard

    os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide"

    from pprint import pprint
    from random import choice, randint, random

    from pygame import mixer
    mixer.pre_init(44100, -16, 2, 2048)
    mixer.init()

except ModuleNotFoundError:
    os.system("cls" if os.name == "nt" else "clear")
    print("\033[1;31;40mHOLD IT!!!")
    time.sleep(1.5)
    print("\033[1;32;40mSome things are missing.")
    time.sleep(1.5)
    print(f"Try running the \033[1;33;40m{'windows_install.bat' if os.name == 'nt' else 'unix_install.sh'} \033[1;32;40mfile,", end="", flush=True)
    time.sleep(1.5)
    print(" THEN try starting the game up again.")
    time.sleep(1.5)
    input("\nPress \033[1;33;40m\"Enter\" \033[0;37;40mto exit: ")
    sys.exit()

isWindows = os.name == "nt"
clearCom = "cls" if isWindows else "clear"
home_dir = os.environ["HOMEPATH"] if isWindows else os.environ["HOME"]

defaultSize = False if len(sys.argv) > 1 else True

colors = [f"\\033[38;5;{i}m" for i in range(256)]

def clear():
    os.system(clearCom)

def change_title(title):
    if isWindows:
        os.system(f"title {title}")
    else:
        os.system(f"echo -n -e 033]{title}007")

def resize(rows, columns, default_sz=False):
    if isWindows:
        subprocess.call(["windows_resize.bat", [f"{default_sz}"]])
    else:
        subprocess.call(["./unix_resize.sh", [f"{default_sz}"]])

def invalidInput(line):
    print(f"\033[1;33;40mLine {line}: \033[1;31;40mInvalid input, please try again.\033[0;37;40m")

def free(amount_freed=1):
    values = [None] * amount_freed
    return values

def printRoman(number):
    #number = int(number)
    num = (1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000)
    sym = ("I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M")

    full = "" if number > 0 else "-"
    if not number > 0:
        number -= (number * 2)
    i = 12

    while number:
        div = number // num[i]
        number %= num[i]
        while div:
            full = full + sym[i]
            div -= 1
        i -= 1

    num, sym, i = free(3)
    return full

