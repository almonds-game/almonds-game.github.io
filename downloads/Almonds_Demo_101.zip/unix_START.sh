#!/bin/sh
# cd $HOME/downloads/almonds_demo
./unix_resize.sh false
python3 troll.py 1
