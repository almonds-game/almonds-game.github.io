from bs4 import BeautifulSoup as bs
import requests
import time
import sys
import os
try:
    ugly = requests.get("https://almonds-game.github.io/downloads")
except requests.exceptions.ConnectionError:
    sys.exit()

if "404" in ugly:
    print("Unable to connect to \033[1;31;40mhttps://almonds-game.github.io/downloads\033[0;37;40m.")
    print("\033[1;31;40m404 Error.")
    sys.exit()

page = bs(ugly.text, "html.parser")
current = page.find_all(text="Almonds_Demo_101.zip") # Checks if its version number is in html file
if len(current) == 0: # if there were no mentions of the version specified, download it
    print("\033[1;32;40mUpdate found!")
    time.sleep(1.3)
    print("(It is only a .zip file and will not replace your current files until unzipped.)")
    time.sleep(1.3)
    confirm = input("Would you like to download the update? \033[0;37;40m(\033[1;32;40my\033[0;37;40m/\033[1;31;30mn\033[0;37;40m):").strip().casefold()
    if conirm == "y":
        print("\n\033[1;32;40mGreat! Downloading now...\033[0;37;40m")
        latest = page.find('p').string
        os.system(f"curl -o {latest} https://raw.githubusercontent.com/almonds-game/almonds-game.github.io/main/downloads/{latest}")
        print("Download complete! Enjoy the new version!")
        sys.exit()
    else:
        print("\033[1;31;40mNot downloading now.\033[0;37;40m")
        system.exit()
