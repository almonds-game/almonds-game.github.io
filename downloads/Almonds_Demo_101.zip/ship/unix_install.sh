#!/bin/sh
rm *.bat
pip3 install -r requirements.txt
