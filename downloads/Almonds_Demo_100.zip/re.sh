#!/bin/sh
printf '\e[8;32;100t'
