#!/bin/sh
rm *.bat
pip3 install -r requirements.txt && clear && echo "\033[1;32;40mDone!\033[0;37;40m"
